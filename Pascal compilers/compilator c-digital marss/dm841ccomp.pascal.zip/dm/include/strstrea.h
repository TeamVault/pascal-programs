
// This is the old version of strstream, before we could rely on
// long filename support.

#include <strstream.h>
