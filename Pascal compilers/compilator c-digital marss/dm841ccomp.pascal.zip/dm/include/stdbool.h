/* Copyright (C) 2001 by Digital Mars */
/* www.digitalmars.com */

#if __DMC__ || __RCC__
#pragma once
#endif

#ifndef __STDBOOL_H
#define __STDBOOL_H 1

#define bool _Bool
#define true 1
#define false 0
#define __bool_true_false_are_defined 1

#endif
