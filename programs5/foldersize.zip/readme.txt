Folder Size
-----------

Version 1.31
12 June 2001


This program scans a selected drive or folder and reports the size of all the folders.
The size can be viewed in bytes, percentage of total space or as a bar graph. Screen Grab

This is a standalone EXE. No installer, DLL's or Registry entries needed. To get rid of it, simply delete the EXE.

History
-------
1.31 Fix for files bigger than 2GB reporting negative sizes. 
1.3  Minor fixes including reading correct size from compressed NT drives
1.2  Added options and colored folders
1.1  Added bargraphs
1.0  First Version


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
