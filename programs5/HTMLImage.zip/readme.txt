HTML Image Page Builder
-----------------------

Version 1.1
01 January 2001


I really like this program and it is being used by many people.
The program takes an image and then converts the image to text and displays it as an HTML page. The text of the HTML page can be binary, numbers, random characters or a copy of a proper text file. Along with the ZIP file is a sample page made from the Arnold Schwarzenegger image.

This is a standalone EXE. No installer, DLL's or Registry entries needed. To get rid of it, simply delete the EXE.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
