ActiveX OpenGL
--------------

In this example I have created an ActiveX control that has an OpenGL scene rendering to a TPanel. I don�t have any user interaction to the active X control, but that would not be difficult because you simply use the normal mouse and keypress events on the panel.

I have provided the source, but it might not work in other versions of Delphi, so here is a description of how I went about it ...
 - Start by creating a new ActiveForm (File | new | ActiveX)
 - Then add a panel to the form.
 - Add a timer to the form. We can�t use Application.onIdle in ActiveX controls
 - You can now decide which properties and methods you want to expose (View | Type Library)
 - Now just use the glDraw, Init, FormCreate, PanelResize and Timercode I used.

Remember that ActiveX controls only work on IE browsers and if you want to use textures, they have to be compiled in the application resource or you can download them at runtime like I did in a previous application.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
