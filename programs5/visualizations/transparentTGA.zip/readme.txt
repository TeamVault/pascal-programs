Transparent TGA Alpha example
-----------------------------

This example demos three new features.
 - Using compressed TGA files
 - Using the transparent alpha channel to display textures with transparent areas
 - Fog.

Using transparent TGA files you can create complex looking objects while still drawing only one quad. In this example there is never more than 20 quads on the screen. This technique is perfect when drawing objects like trees, fences .. etc in a landscape

These files are basically normal images with a built in mask. To create/edit these files in an application like PaintShopPro, open up the image, go to Masks and select "Load from Alpha Channel". You can then edit and save a new mask.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn