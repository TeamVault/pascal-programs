Optimize 2001 Intro
-------------------

Optimize is South Africa�s demo scene that happens every year. This year its 23, 24 November and its held in Midrand. One of the other people attending the event made this cool background and when I saw it this image of metaballs on the one side just came to mind, so I released this intro. It was a 15 minute project, but the "environment" mapping sucks. At the time I didn�t know how to get the environment mapping working, but now I do. Wait for my demo to see some really cool environment mapped metaballs.

This little intro also plays a midi file for some background music. All the textures and the midi gets compiled into the EXE.

Use your arrow keys to scroll the text up and down.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
