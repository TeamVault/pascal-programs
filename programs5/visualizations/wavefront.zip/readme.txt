Wavefron OBJ Loader
-------------------

The code loads models from alias wavefront OBJ files including their material properties.

At the moment it loads a basic model that can contain multiple groups and multiple materials. 

Knows Issues
 - The code for loading the actual texture file for a material is not present, because the texture can be any format.
 - The program only reads files where the lines are seperated by a Enter and Line Feed. #13#10. So any models where the line seperator is #10 will have to be converted to #13#10 using a text editor. OR you can change the code to load any format. If you do Please let me know sothat I can add it to the base code.
 - Bezier, special curver and B-Spline support has not yet been addded.

If you have any queries or bug reports, please mail me.

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

