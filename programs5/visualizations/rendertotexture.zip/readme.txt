Render To Texture
-----------------

This app demonstrates how to render to a texture using the glCopyToTexture function. I have used one of my old projects to create a interesting effect (Blending colors). This is rendered to a viewport and then copied to a texture. The texture is then applied to a cube.

To change to another texture press T. There are 6 different textures. If you want to see the texture being created, press B to see it in the background.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn