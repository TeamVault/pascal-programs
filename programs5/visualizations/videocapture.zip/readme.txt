Video Capture
-------------

This is a slightly different project to most. I wrote an application that would sit on a PC at our office reception. There is a video camera attached to the PC via a USB port. The program then gets each frame from the video feed using DirectCapture from directX and the frame is then converted to a texture. This is then rendered onto a cube using the standard openGL commands. You can render it to an object because its a normal texture.

I have only tested this application with a logitech quickcam, so I don't know if it works with other cameras. As far as I know it will. If you get an error message saying "Cant add video filter onto graph!", try pluggin the camera into another USB port.

You will need DirectX 8 to use this application. 

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
