Delphi OpenGL Collision Detection
----------------------------------

This project basically shows how to do Line Polygon collision detection using Delphi.
			
You can find the original c++ code written by Digiben at www.gametutorials.com

If you have any queries or bug reports, please mail me.

Code : Maarten Kronberger
Mail : maartenk@tinderbox.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
