NURBS (Non-Uniform Rational B-Spline)
-------------------------------------

Description from MSDN : Non-Uniform Rational B-Spline (NURBS) functions provide general and powerful descriptions of curves and surfaces in two and three dimensions, converting the curves and surfaces to OpenGL evaluators. NURBS can render curves and surfaces in a variety of styles, and they can automatically handle adaptive subdivision that tessellates the domain into smaller triangles in regions of high curvature and near silhouette edges.

When playing around with this project, have a look at the wireframe view (Press "W") and as you move the control points around, you will see how the Nurbs Renderer will add more lines to the grid to create a smooth surface. This is the "adaptive subdivision that tessellates the domain into smaller triangles.
 
To see this in action, start up the application and enter wireframe mode by pressing "W". Control point sero will automatically be selected, so move it left (Left arrow key), and keep going so for a while. As you do this you will see the grid density increase, and at some point only the quarter with the control point will have a dense grid and the rest will revert to a very sparse grid.

Keys :
 - 0..9 : To select the first 10 control points.
 - Arrow keys : To move the control points left, right forward and backwards
 - PgUp/PgDn : To move the control point up or down
 - W : Toggle wireframe / shaded drawing
 - L : Toggle the control lines on and off.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
