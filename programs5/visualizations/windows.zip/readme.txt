Opengl Windows
--------------

This ZIP contains a sample application as well as a library to create windows in a gl scene. It was adapted from a project by Michael Pote.
win.pas is the pascal library to create the windows. The only code you should need to modify is gui.pas and the gui.tga file to make it look like your GUI.

Adding windows and buttons in gui.pas :
  wMain.Init(300, 260, 300, 250);               // create the window (x, y, width, height)
  wMain.AddButton(185, 60, 75, 25, 'Setup');    // add a button to the window
  wMain.Button[0].onClick :=myProc;             // myProc = procedure declared in gui.pas

If you want to make your own gui skin, use the GUI.tga file. Load it in a program that support 23 bit tga file like PaintShopPro. Load the alpha Channel / Mask (in PSP go to Masks | load from alpha channel)

You can also make your own font set. To determine the widths of the characters, use the bit of code below. It will create the font.fnt file which specifies the character widths.

procedure CreateFNTFile;
type TByteArray = Array of Byte;
var S : TSize;
    I : Integer;
    F : File of Byte;
    C : String;
begin
  AssignFile(F, 'C:\fonts.fnt');
  Rewrite(F);
  for I :=0 to 255 do
  begin
    C :=Chr(I);
    GetTextExtentPoint32(Label1.Canvas.Handle, PChar(C), 1, S);
    write(F, S.cx);
  end;
  CloseFile(F);
end;


To control the window you can click and drag on the caption bar.

At the moment the fonts still dont load property. They are all comming out slightly out of focus. I still need to fix that. The button caption also disappears when you click on it. Needs to get fixed.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
