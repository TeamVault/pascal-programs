The program is allowed to be copied, modified, whatever you want.
If copying please distribute the file with the source and the readme file.
This program was written by Jan Horn.
Other projects with source code can be found on his site www.sulaco.co.za.
Press escape to exit.
Enjoy.  

To Jan
Program in peace.
Murray Horn.
