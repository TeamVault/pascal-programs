Sliding Images
--------------

This program has 64 squares moving from left to right and as they do it they show traces of a "hidden" image. This is done by taking the quad position and mapping only that part of the hidden image onto it.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
