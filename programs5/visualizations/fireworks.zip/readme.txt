Fireworks
---------

With two days to go to the New Year I decided to write a particle system that creates a basic fireworks display. Every now and then a different shape firework is created. The structure is there for you to create any other shapes and they will get displayed.

Keys  : Number pad + and -

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
