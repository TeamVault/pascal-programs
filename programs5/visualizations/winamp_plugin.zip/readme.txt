WinAMP Plugin
-------------

This is my first very basic winamp plugin that uses OpenGL to render 
some 3D VU meters. The program is was created more as a skeleton 
application for other plugins.

I have provided a basic tutorial that explains what all the functions 
are and how to use them. This tutorial can be found on my homepage at 
http://home.global.co.za/~jhorn/winamp_tut.htm

Keys :
 - Left  : Previous song.
 - Right : Next song.
 - Up Arrow   : Increases the Volume.
 - Down Arrow : Decreases the Volume.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

