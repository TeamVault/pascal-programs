Bounce Water
---------------------

A lot of people asked me, "So how do i put it all together?"
I have taken some of the other tutorials and created this piece of eye candy.
It uses slightly modified versions of the Bouncing Ball and Water Ripple tutorials.

If you have any queries or bug reports, please mail me

Code : Maarten Kronberger
Mail :maartenk@tinderbox.co.za
Web  : http://www.sulaco.co.za
             http://www.tinderbox.co.za

