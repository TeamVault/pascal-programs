                        Knot Another Torus
                        ------------------

A demo entry for the SAGameDev 1MB demo competition. (www.sagamedev.co.za)
(Demo including source is 710KB). 


Demo Requirements
  System........      win98/win2k with OpenGL
  Cpu...........      fast pentium 2 (p3 or athlon recommended).
  Video.........      opengl accelerated 3d card.
  Audio.........      windows compatible soundcard.
  
On my home machine (Celeron 450 with a GeForce DDR) the frame rate never
drops below 200fps when running at 800x600. Basically run it at the same
resolution that you would run Quake3 at :)

If you want to see what frame rate you are getting, run the demo 
in a window and press F to see the FPS in the window caption.


Demo created by 
  Code..........      Jan Horn
  Design........      Jan Horn
  Graphics......      Jan Horn (except for the girl that I found
                                somewhere some time ago )
  Music.........      No Idea. Its just one of the 100+ MOD files I have.
  
  
For those who want to see more great demos, keep an eye open for
productions by Haujobb, Farbrauch and Sunflower. These guys rule.


Keys : "F" : Displays the frame rate in the window caption bar. 
             (Only works in window mode)
             

The demo includes the bass.dll which enables it to play the MOD file.
BASS is a sound system for use in Windows 95/98/2000/NT software. 
It's purpose is to provide powerful (yet easy to use) sample, stream,
MOD music, and audio CD playback functions.

The latest version of BASS can always be found at the BASS homepage:
http://www.un4seen.com/music/



For this demo and many others all containing full source code, 
visit my website at : http://www.sulaco.co.za

If you have any queries or bug reports, please mail me.

Name : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn


