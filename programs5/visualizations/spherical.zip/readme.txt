Spherical Environment Mapping
-----------------------------

The program is a simple demonstration of the effects of spherical environment mapping on various standard OpenGL shapes.

Keys : 
  - 1, 2, 3, 4, 5 : different shapes
  - B : Enable/Disable Blending
  - Arrow keys to rotate the objects.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

