Cell Shading
------------

This program was originally created by Sami "MENTAL" Hamlaoui for Tutorial 38 on nehe.gamedev.net. This is the Delphi conversion for the tutorial.

The tutorial demonstrates how to do cell shading.

Keys :
 Space	    - Toggle rotation
 "1"	    - Toggle outline drawing
 "2"	    - Toggle outline anti-alaising (Smooth lines)
 Up Arrow   - Increase line width
 Down Arrow - Decrease line width


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
