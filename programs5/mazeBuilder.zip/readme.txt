Maze Builder
-----------

Version 1.0
22 December 2001

This program generates random mazes of various sizes and then solves the mazes. The mazes can be saved as BMP files. Each maze has only one solution. 

The maze solving is not the fastest solution, but it does usea little bit of intelegence when solving the maze. Its not simple a case of sticking to the left. When the program gets to a branch in the path, it first check to see which of the directions is closer to the final destination. 
eg. When going from top left to bottom right if there is a crossroad with one path to the left and one down and the "cursor" is at (25, 15) in a 30x30 maze, then there are only 5 units remaining to the right, so it will take the ath to the right.

This is a standalone EXE. No installer, DLL's or Registry entries needed. To get rid of it, simply delete the EXE.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
